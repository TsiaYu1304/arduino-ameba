#ifndef __WIFI_OPTS_H_
#define __WIFI_OPTS_H_


// options

#define MAX_JOIN_TIMEOUT	10000
#define	SCANQUEUE_LIFETIME 20 // unit:sec





#endif // __WIFI_OPTS_H_
