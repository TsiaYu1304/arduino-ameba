/*
 * rom_libc_string.h
 *
 * Definitions for standard library - libc functions.
 */
#ifndef _ROM_LIBC_H_
#define	_ROM_LIBC_H_

#include "../rom/string/rom_libc_string.h"
#include "../../libgloss/rtl8195a/rom/rom_libgloss_retarget.h"

#endif /* _ROM_LIBC_H_ */
