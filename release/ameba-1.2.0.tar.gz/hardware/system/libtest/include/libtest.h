#ifndef __LIBTEST_H__
#define __LIBTEST_H__


#ifdef __cplusplus
extern "C" {
#endif


extern int mysum(int a, int b);


#ifdef __cplusplus
}
#endif


#endif // __LIBTEST_H__

