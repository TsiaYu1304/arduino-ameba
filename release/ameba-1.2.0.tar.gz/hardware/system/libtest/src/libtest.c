
#include "libtest.h"

int mysum(int a, int b)
{
    return a+b;
}
