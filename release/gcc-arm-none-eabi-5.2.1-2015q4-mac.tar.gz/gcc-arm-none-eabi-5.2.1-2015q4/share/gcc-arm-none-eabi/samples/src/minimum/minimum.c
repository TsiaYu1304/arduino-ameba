#ifndef __NO_SYSTEM_INIT
void SystemInit()
{}
#endif

void main()
{
	for (;;);
}
